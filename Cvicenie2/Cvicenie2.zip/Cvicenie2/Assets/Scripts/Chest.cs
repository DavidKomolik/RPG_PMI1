﻿using UnityEngine;

public class Chest : MonoBehaviour
{
    [SerializeField] GameObject coinPrefab;

    private bool _isPlayerInRange;

    private void OnMouseDown()
    {
        if (_isPlayerInRange)
        {
            Debug.Log("Chest opened");
            Instantiate(coinPrefab, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            _isPlayerInRange = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            _isPlayerInRange = false;
        }
    }
}
