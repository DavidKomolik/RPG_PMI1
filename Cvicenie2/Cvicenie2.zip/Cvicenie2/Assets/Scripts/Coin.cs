﻿using UnityEngine;

public class Coin : MonoBehaviour
{
    private bool _isPlayerInRange;

    private void OnMouseDown()
    {
        if (_isPlayerInRange)
        {
            Debug.Log("Coin collected");
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            _isPlayerInRange = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            _isPlayerInRange = false;
        }
    }
}
